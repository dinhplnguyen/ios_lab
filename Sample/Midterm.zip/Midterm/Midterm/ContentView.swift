//
//  ContentView.swift
//  Midterm
//
//  Created by Dinh Phi Long Nguyen on 2022-10-20.
//

import SwiftUI

struct ContentView: View {
    @State var restaurants = [Restaurant]()
    @State var address : String = ""
    
    var body: some View {
        
        VStack {
            
            Banner()
            
            NavigationView {
                
                VStack(alignment: .leading) {
                    List(restaurants) { restaurant in
                        
                        NavigationLink(restaurant.name, destination:{
                            AddressView(rest: restaurant)
                            
                        })
                        .font(.subheadline)
                        
                    }.navigationTitle("Restaurants")
                    
                }
            }
            .padding()
            .onAppear() {
                RestaurantAPI().loadData(completion: {
                    (restaurant) in
                    self.restaurants = restaurant
                })
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
