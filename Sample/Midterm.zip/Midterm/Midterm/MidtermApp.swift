//
//  MidtermApp.swift
//  Midterm
//
//  Created by Dinh Phi Long Nguyen on 2022-10-20.
//

import SwiftUI

@main
struct MidtermApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
