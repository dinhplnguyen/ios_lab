//
//  RestaurantAPI.swift
//  Midterm
//
//  Created by Dinh Phi Long Nguyen on 2022-10-21.
//

import Foundation

class RestaurantAPI : ObservableObject{
    @Published var restaurants = [Restaurant]()
    
    func loadData(completion:@escaping ([Restaurant]) -> ()) {
        guard let url = URL(string: "https://apipool.azurewebsites.net/api/restaurants") else {
            print("Invalid url...")
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            let restaurants = try! JSONDecoder().decode([Restaurant].self, from: data!)
            print(restaurants)
            DispatchQueue.main.async {
                completion(restaurants)
            }
        }.resume()
    }
}
