//
//  Restaurant.swift
//  Midterm
//
//  Created by Dinh Phi Long Nguyen on 2022-10-21.
//

import Foundation

struct Restaurant: Codable, Identifiable {
    var id: Int
    var name: String
    var street: String
    var city: String
    var province: String
    var postalCode: String
    var country: String
    var foodType: String
    var phone: String
    var logoUrl: String
    enum CodingKeys: String, CodingKey { case id = "restaurantId"
        case name = "restaurantName"
        case street
        case city
        case province
        case postalCode
        case country
        case foodType
        case phone
        case logoUrl
        
    }
}
