//
//  Banner.swift
//  Midterm
//
//  Created by Dinh Phi Long Nguyen on 2022-10-21.
//

import SwiftUI

struct Banner: View {
    var body: some View {
        HStack {
            VStack {
                Text("Dinh Phi Long Nguyen \n A01163284")
                    .foregroundColor(.yellow)
            }
            Image("Dinh")
                .resizable()
                .frame(width: 80, height: 100)
                
        }
        .frame(
              minWidth: 0,
              maxWidth: .infinity,
              minHeight: 0,
              alignment: .bottom
            )
        .background(.black)
    }
}

struct Banner_Previews: PreviewProvider {
    static var previews: some View {
        Banner()
    }
}
