//
//  SubView.swift
//  Midterm
//
//  Created by Dinh Phi Long Nguyen on 2022-10-21.
//

import SwiftUI

struct AddressView: View {
    @State var rest : Restaurant?
    
    var body: some View {
        
        if let restaurant = rest {
            AsyncImage(url: URL(string: restaurant.logoUrl)) { image in
                image
                    .resizable()
                    .scaledToFill()
            } placeholder: {
                Color.purple.opacity(0.1)
            }
            .frame(width: 100, height: 100)
            
            Text(restaurant.name)
                .foregroundColor(.primary)
                .font(.title)
                .fontWeight(.bold)
                .padding()
            
            Text(restaurant.foodType)
                .foregroundColor(.primary)
                .font(.title3)
                .fontWeight(.bold)
            
            Divider()
            
            Text(restaurant.street)
                .foregroundColor(.secondary)
                .font(.title2)
                .fontWeight(.semibold)
            
            Text(restaurant.city)
                .foregroundColor(.secondary)
                .font(.title2)
                .fontWeight(.semibold)

            Text(restaurant.postalCode)
                .foregroundColor(.secondary)
                .font(.title2)
                .fontWeight(.semibold)

            Text(restaurant.phone)
                .foregroundColor(.secondary)
                .font(.title2)
                .fontWeight(.semibold)
        }
        
        
        
        
        
    }
}

struct SubView_Previews: PreviewProvider {
    static var previews: some View {
        AddressView()
    }
}
